export class tag {
  name!: string;
  count?: number;
}
