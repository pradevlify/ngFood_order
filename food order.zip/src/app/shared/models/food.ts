export class foods {
  id!: number;
  price!: number;
  name!: string;
  favorite!: boolean;
  star?: number;
  tags!: string[];
  imageUrl!: string;
  origins!: string[];
  cooktime!: string;
}
